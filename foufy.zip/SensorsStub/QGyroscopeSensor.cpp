#include "QGyroscopeSensor.h"
#include <QLabel>
#include <QGridLayout>
#include <QPushButton>
#include <QFormLayout>



QGyroscopeSensor::QGyroscopeSensor(QString widgetTitle, QString logoName, QWidget *parent) :
    QWidgetSensorAbstract(widgetTitle, logoName)
{


    auto *formLayout = new QFormLayout();

    this->xValueSpinbx = new QDoubleSpinBox(this);
    this->yValueSpinbx = new QDoubleSpinBox(this);
    this->zValueSpinbx = new QDoubleSpinBox(this);


    formLayout->addRow(new QLabel("X value"), this->xValueSpinbx);
    formLayout->addRow(new QLabel("Y value"), this->yValueSpinbx);
    formLayout->addRow(new QLabel("Z value"), this->zValueSpinbx);

    setInputsLayout(formLayout);

}

void QGyroscopeSensor::onSendClicked()
{
    auto xVal = this->xValueSpinbx->value();
    auto yVal = this->yValueSpinbx->value();
    auto zVal = this->zValueSpinbx->value();

    QString msg = QString("GYRO: %1;%2;%3\n").arg(xVal).arg(yVal).arg(zVal);
    emit sending(msg);
}
