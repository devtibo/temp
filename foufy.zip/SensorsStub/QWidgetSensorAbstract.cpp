#include "QWidgetSensorAbstract.h"

#include <QWidget>
#include <QFrame>
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>

void QWidgetSensorAbstract::setInputsLayout(QLayout *layout)
{
    this->widget()->layout()->itemAt(1)->widget()->setLayout(layout);
}

QWidgetSensorAbstract::QWidgetSensorAbstract(QString widgetTitle, QString logoName, QWidget *parent) : QDockWidget(parent)
{
    auto *mainWidget = new QFrame(this);
    mainWidget->setFrameStyle(QFrame::StyledPanel | QFrame::Sunken);
    auto *mainLayout = new QVBoxLayout();

    QPixmap pixmap(logoName);
    auto *logoLabel = new QLabel("Geolocalisation logo", this);
    logoLabel->setPixmap(pixmap.scaled(128, 128, Qt::KeepAspectRatio));

    auto *sendButton = new QPushButton("Send", this);


    mainLayout->addWidget(logoLabel,0,  Qt::AlignCenter);
    mainLayout->addWidget(new QWidget(this), 0);
    mainLayout->addWidget(sendButton, 1, Qt::AlignHCenter | Qt::AlignBottom);


    mainWidget->setLayout(mainLayout);
    this->setWidget(mainWidget);

    this->setWindowTitle(widgetTitle);

    connect(sendButton, &QPushButton::clicked, this, &QWidgetSensorAbstract::onSendClicked);
}
