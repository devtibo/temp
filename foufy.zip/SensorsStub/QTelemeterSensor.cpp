#include "QTelemeterSensor.h"
#include <QLabel>
#include <QGridLayout>
#include <QPushButton>


QTelemeterSensor::QTelemeterSensor(QString widgetTitle, QString logoName, QWidget *parent) :
    QWidgetSensorAbstract(widgetTitle, logoName)
{

    auto inputLayout = new QHBoxLayout();

    this->valueSpinbox = new QDoubleSpinBox(this);
    auto *spinLabel = new QLabel(widgetTitle, this);

    inputLayout->addWidget(spinLabel);
    inputLayout->addWidget(this->valueSpinbox);

    setInputsLayout(inputLayout);

}

void QTelemeterSensor::onSendClicked()
{
    auto val = this->valueSpinbox->value();

    QString msg = QString("DIST: %1\n").arg(val);
    emit sending(msg);
}
