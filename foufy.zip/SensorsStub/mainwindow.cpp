#include "mainwindow.h"
#include <QHBoxLayout>
#include <QDebug>

#include "QTelemeterSensor.h"
#include "QGyroscopeSensor.h"
#include "QGeolocalisationSensor.h"

#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
//#include <sys/types.h>

char shm_name[10];
char sema_name[10];


#include <semaphore.h>

sem_t *sema;


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    /*
    auto *mainWidget = new QWidget(this);
    auto *mainLayout = new QHBoxLayout(this);

    mainLayout->addWidget(telemeterSensor);


    mainWidget->setLayout(mainLayout);
    this->setCentralWidget(mainWidget);
    */
    QTelemeterSensor *telemeterSensor = new QTelemeterSensor("Telemeter", ":/icons/telemeter.png", this);
    QGyroscopeSensor *gyroscopeSensor = new QGyroscopeSensor("Gyro", ":/icons/gyroscope.png", this);
    QGeolocalisationSensor *geolocalisationSensor = new QGeolocalisationSensor("Geoloc", ":/icons/geolocalisation.jpg", this);

    connect(telemeterSensor, &QTelemeterSensor::sending, this, &MainWindow::onSending);
    connect(gyroscopeSensor, &QGyroscopeSensor::sending, this, &MainWindow::onSending);
    connect(geolocalisationSensor, &QGeolocalisationSensor::sending, this, &MainWindow::onSending);


    this->addDockWidget(Qt::TopDockWidgetArea, telemeterSensor);
    this->addDockWidget(Qt::TopDockWidgetArea, gyroscopeSensor);
    this->addDockWidget(Qt::TopDockWidgetArea, geolocalisationSensor);


    /* SEMAPHORE */

    int ret;
    strcpy(sema_name, "sem_test");


    uint initialValue = 0; // initialy unlock
    sema = sem_open(sema_name, O_CREAT, 0700, initialValue);
    if (sema == SEM_FAILED)
        printf("sem_open Error");

    sem_wait(sema); //wait for lock
    sem_trywait(sema); // try to lock, else ignored


    sem_post(sema); // unlock



    //sem_trywait(sema); // wait for lock



    /*sem_post();
    sem_trywait();
    same_wait();*/

    sem_close(sema);

    /* Init and Open Shared memeory */

    strcpy(shm_name, "shm_test");
    int size = sizeof(char)*10;

    /* Remove if already exists*/
    ret = shm_unlink(shm_name);
    if (ret < 0 && errno != ENOENT)
        printf("Unlink Error");

    int fd = shm_open(shm_name, O_CREAT | O_RDWR, 0755);
    if (fd < 0)
        printf("Open error");

    ret = ftruncate(fd, size);
    if (ret)
        printf("ftruncate error");

    uchar *data = (unsigned char *)mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (!data)
        printf("NMap error");

    /* Write data to SHM */
    strcpy((char*)data,"Hello");

    munmap(data, size); // unmap data

    ::close(fd); // close io

}

MainWindow::~MainWindow()
{
    int ret = shm_unlink(shm_name);
    if (ret < 0 && errno != ENOENT)
        printf("shm_unlink Error");
    //free (shm_name);


    ret = sem_unlink(sema_name);
    if (ret < 0 && errno != ENOENT)
        printf("sem_unlink Error");

    //free(sema_name);


}

void MainWindow::onSending(QString msg)
{
    qDebug() << msg;
}

