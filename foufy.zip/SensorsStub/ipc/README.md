# ipc
Public domain, cross platform, single header inter-process communication primitives.

This is a "stb like" public domain header-only C/C++ library that provides 
inter process communication functionality, released under unlicense.

In Linux and similar, link with "-lpthread -lrt". Windows doesn't need
anything special.

See header for documentation.
