#ifndef QWIDGETSENSORABSTRACT_H
#define QWIDGETSENSORABSTRACT_H

#include <QDockWidget>
#include <QLayout>


class QWidgetSensorAbstract : public QDockWidget
{
    Q_OBJECT

    QLayout *inputsLayout;

protected:
    void setInputsLayout(QLayout *layout);

public:
    explicit QWidgetSensorAbstract(QString widgetTitle, QString logoName, QWidget *parent = nullptr);
    virtual void onSendClicked() = 0;

signals:
    void sending(QString);
};

#endif // QWIDGETSENSORABSTRACT_H
