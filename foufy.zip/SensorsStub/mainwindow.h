#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ipc/ipc.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

    int pid;
    ipc_sharedsemaphore coop;
    ipc_sharedmemory mem;

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void initSharedMemory();
    void closeSharedMemory();
    int myprocessid();

public slots:
    void onSending(QString);
};
#endif // MAINWINDOW_H
