#ifndef QGEOLOCALISATIONSENSOR_H
#define QGEOLOCALISATIONSENSOR_H

#include "QWidgetSensorAbstract.h"
#include <QDoubleSpinBox>

class QGeolocalisationSensor  : public QWidgetSensorAbstract
{
    Q_OBJECT
    QDoubleSpinBox *xValueSpinbx;
    QDoubleSpinBox *yValueSpinbx;
    QDoubleSpinBox *zValueSpinbx;

public:
    explicit QGeolocalisationSensor(QString widgetTitle, QString logoName, QWidget *parent = nullptr);
    void onSendClicked() override;


signals:
    void sending(QString);
};

#endif // QGEOLOCALISATIONSENSOR_H
