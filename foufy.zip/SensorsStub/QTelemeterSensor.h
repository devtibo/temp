#ifndef QTELEMETERSENSOR_H
#define QTELEMETERSENSOR_H

#include "QWidgetSensorAbstract.h"
#include <QDockWidget>
#include <QDoubleSpinBox>


class QTelemeterSensor : public QWidgetSensorAbstract
{
    Q_OBJECT

    QDoubleSpinBox *valueSpinbox;

public:
    explicit QTelemeterSensor(QString widgetTitle, QString logoName, QWidget *parent = nullptr);
    void onSendClicked() override;

};

#endif // QTELEMETERSENSOR_H
