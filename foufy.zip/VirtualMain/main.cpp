#include <QCoreApplication>

#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <string.h>


int main(int argc, char *argv[])
{

    int ret;
    char *name = "shm_test";
    int size = sizeof(char)*10;



    int fd = shm_open(name, O_CREAT | O_RDWR, 0755);
    if (fd < 0)
        printf("Open error");

    ftruncate(fd, size);

    uchar *data = (unsigned char *)mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (!data)
        printf("NMap error");

    printf("TUTU: %s", data);

    munmap(data, size); // unmap

    ::close(fd); // close io

    //ret = shm_unlink(name); // remove file

    return 0; //a.exec();
}


